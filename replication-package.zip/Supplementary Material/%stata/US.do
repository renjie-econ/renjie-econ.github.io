********************************************************************************
* Input: household level data from IPUMS:USA
* Output: U.S. unincorporated/incorporated labor shares and t-test for changes, 
*         average marginal effect of schooling years and secondary school completion 
********************************************************************************

clear all 
set more off, perm
set scheme s2mono

global data  "~/data/ipums_usa"
global results  "~/results"


clear 
cd $USdata

* labor shares 
local cid=0
foreach y of numlist 1970 1980 1990 2000/2017 1{	
	
	local ++cid
	disp `y'

if `y'>=1980 & `y'<=2000  {
	use "$USdata/`y'.dta",clear
append using "$USdata/1970.dta",nolabel
}
else if `y'==1970 | (`y'>=2001 & `y'<=2017) {
	use "$USdata/`y'.dta",clear
} 
else if `y'==1 { // pooled 2001-2017
	use "$USdata/2001.dta",clear
	append using "$USdata/1970.dta",nolabel
	foreach n of numlist 2002/2017 {
		disp `n'
		append using "$USdata/`n'",nolabel
	}
	replace year=1 if year~=1970
}

* GQ (Group quarters status): 0 Vacant unit, 1 Households under 1970 definiton, 2 Additional households under 1990 definition, 3 Institutions, 4 Other group quarters 5 Additional households under 2000 definition
qui keep if inlist(gq,1,2,5) // 
qui keep if sex == 1 // Male 
qui keep if age>=25  & age<=54	

svyset [pw=perwt], strata(year)
* CLASSWKR (Class of worker): 2 Works for wages
* CLASSWKRD: 13 Self-employed, not incorporated, 14 Self-employed, incorporated
qui gen incor=(classwkrd==14) // incorporated self-employed 
qui gen unincor=(classwkrd==13) // unincorporated self-employed
qui gen wage=(classwkr==2) //wage workers
qui drop if (incor==0 & unincor==0 & wage==0)

if `y'==1970 | (`y'>=2001 & `y'<=2017) {
	collapse (mean) incor_share=incor unincor_share=unincor [pw=perwt], by(year)
}
else {
svy: mean unincor, over(year) coeflegend
qui gen unincor_share=_b[c.unincor@`y'.year]
lincom _b[c.unincor@`y'.year]- _b[c.unincor@1970bn.year]
qui gen unincor_gap=r(estimate)
qui gen unincor_gap_pvalue=r(p)
svy: mean incor, over(year) coeflegend
qui gen incor_share=_b[c.incor@`y'.year]
lincom _b[c.incor@`y'.year]- _b[c.incor@1970bn.year]
qui gen incor_gap=r(estimate)
qui gen incor_gap_pvalue=r(p)
qui keep incor_gap incor_gap_pvalue unincor_gap unincor_gap_pvalue incor_share unincor_share
qui duplicates drop
qui gen year=`y'
}

if `cid'==1 {
	save "$results/labor_shares_us.dta",replace
}
else {
	append using "$results/labor_shares_us.dta",nolabel
    save "$results/labor_shares_us.dta",replace
}
}

* multinomial probit model to estimate the effects of schooling years 
local cid=0
foreach y of numlist 1970 1980 1990 2000/2017 1 {	
	
	local ++cid
	disp `y'

if `y'~=1{
	use "$USdata/`y'.dta",clear
} 
else if `y'==1 {
	use "$USdata/2001.dta",clear
	foreach n of numlist 2002/2017 {
		disp `n'
		append using "$USdata/`n'",nolabel
	}
	replace year=1
}

* GQ (Group quarters status): 0 Vacant unit, 1 Households under 1970 definiton, 2 Additional households under 1990 definition, 3 Institutions, 4 Other group quarters 5 Additional households under 2000 definition
qui keep if inlist(gq,1,2,5) // 
qui keep if sex == 1 // Male 
qui keep if age>=25  & age<=54	

gen age2=age^2
* bpl (birthplace): >099: US OUTLYING AREAS/TERRITORIES or other countries 
qui drop if bpl==. | bpl==999
* nativity: 0 foreign-born; 1 Native-born
qui gen nativity=0
qui replace nativity=1 if bpl<=99

* years of schooling
qui gen yrschool=.
qui replace yrschool=0 if inlist(educd,2,10,11,12)
qui replace yrschool=1 if inlist(educd,14)
qui replace yrschool=2 if inlist(educd,13,15)
qui replace yrschool=3 if inlist(educd,16)
qui replace yrschool=4 if inlist(educd,17)
qui replace yrschool=5 if inlist(educd,21,22)
qui replace yrschool=6 if inlist(educd,20,23)
qui replace yrschool=7 if inlist(educd,24,25)
qui replace yrschool=8 if inlist(educd,26)
qui replace yrschool=9 if inlist(educd,30)
qui replace yrschool=10 if inlist(educd,40)
qui replace yrschool=11 if inlist(educd,50)
qui replace yrschool=12 if inlist(educd,60,61,62,63,64,65)
qui replace yrschool=13 if inlist(educd,70,71)
qui replace yrschool=14 if inlist(educd,80,81,82,83)
qui replace yrschool=15 if inlist(educd,90)
qui replace yrschool=16 if inlist(educd,100,101)
qui replace yrschool=17 if inlist(educd,110)
qui replace yrschool=18 if inlist(educd,111,112,113,114,115,116)
qui drop if yrschool==.

*** Multinomia Choice: 0=unincorporated, 1=incorporated, 2=wage worker  
* CLASSWKR (Class of worker): 2 Works for wages
* CLASSWKRD: 13 Self-employed, not incorporated, 14 Self-employed, incorporated
qui gen job=.
qui replace job=0 if classwkrd==13
qui replace job=1 if classwkrd==14
qui replace job=2 if classwkr==2
qui drop if job==.
qui label define joblabel 0 "unincorporated" 1 "incorporated" 2 "wage"
qui label values job joblabel

qui keep job yrschool age age2 nativity perwt
mprobit job yrschool age age2 nativity [pw=perwt], robust
margins [pw=perwt], dydx(yrschool) coeflegend post
regsave, tstat pva ci
gen year=`y'

if `cid'==1 {
	save "$results/mp_yrs_us.dta",replace
}
else {
	append using "$results/mp_yrs_us.dta",nolabel
    save "$results/mp_yrs_us.dta",replace
}
}

* multinomial probit model to estimate the effects of university completion 
local cid=1
foreach y of numlist 1980 1990 2000/2017{	
	
	local ++cid
	disp `y'


	use "$USdata/`y'.dta",clear

* GQ (Group quarters status): 0 Vacant unit, 1 Households under 1970 definiton, 2 Additional households under 1990 definition, 3 Institutions, 4 Other group quarters 5 Additional households under 2000 definition
qui keep if inlist(gq,1,2,5) // 
qui keep if sex == 1 // Male 
qui keep if age>=25  & age<=54	

gen age2=age^2
* bpl (birthplace): >099: US OUTLYING AREAS/TERRITORIES or other countries 
qui drop if bpl==. | bpl==999
* nativity: 0 foreign-born; 1 Native-born
qui gen nativity=0
qui replace nativity=1 if bpl<=99

* EDUC (educational attainment):00 N/A or no schooling (001 N/A),01 Nursery school to grade 4, 02 Grade 5, 6, 7, or 8, 03 Grade 9, 04 Grade 10, 05 Grade 11, 06 Grade 12, 07 1 year of college, 08 2 years of college, 09 3 years of college, 10 4 years of college, 11  5+ years of college
* educd: 000 N/A or no schooling, 001 N/A, 002 no schooling completed
qui drop if educd==000 | educd==001 
qui gen uni = (educ>=10) //university completed

*** Multinomia Choice: 0=unincorporated, 1=incorporated, 2=wage worker  
* CLASSWKR (Class of worker): 2 Works for wages
* CLASSWKRD: 13 Self-employed, not incorporated, 14 Self-employed, incorporated
qui gen job=.
qui replace job=0 if classwkrd==13
qui replace job=1 if classwkrd==14
qui replace job=2 if classwkr==2
qui drop if job==.
qui label define joblabel 0 "unincorporated" 1 "incorporated" 2 "wage"
qui label values job joblabel

qui keep job uni age age2 nativity perwt
mprobit job i.uni age age2 nativity [pw=perwt], robust
margins uni [pw=perwt],coeflegend post

* the effect of "university completed" on the choice of being a own-account worker
quietly lincomest _b[1bn._predict#1.uni]-_b[1bn._predict#0bn.uni],holdname(own) 
parmest, norestore
drop parm
rename * =_own
gen year=`y'
tempfile temp 
save `temp',replace

_estimates unhold own

* the effect of "university completed" on the choice of being an employer
quietly lincomest _b[2._predict#1.uni]-_b[2._predict#0bn.uni]
parmest, norestore
drop parm
rename * =_employer
gen year=`y'
merge 1:1 year using `temp'
drop _merge 

if `cid'==1 {
save "$results/mp_uni_us.dta",replace
}
else {
append using "$results/mp_uni_us.dta",nolabel
save "$results/mp_uni_us.dta",replace
}
}

********************************************************************************
*                           Merge with GDP Data	    	                       *
********************************************************************************
use "$results/labor_shares_us.dta",clear
gen countrycode="USA"
merge m:1 countrycode year using "~/data/gdppc.dta",keepusing(gdppc ln_gdppc)
drop if _merge==2 
drop _merge
order year 
save "$results/labor_shares_us.dta",replace 

use "$results/mp_yrs_us.dta",clear
preserve
keep if var=="yrschool:2._predict"
drop var
rename * =_employer 
rename year_employer year
tempfile temp
save `temp'
restore 

keep if var=="yrschool:1bn._predict"
drop var
rename * =_own
rename year_own year
merge 1:1 year using `temp'
drop _merge 

gen countrycode="USA"
merge m:1 countrycode year using "~/data/gdppc.dta",keepusing(gdppc ln_gdppc)
drop if _merge==2 
drop _merge
order year 
save "$results/mp_yrs_us.dta",replace 

use "$results/mp_uni_us.dta",clear
gen countrycode="USA"
merge m:1 countrycode year using "~/data/gdppc.dta",keepusing(gdppc ln_gdppc)
drop if _merge==2 
drop _merge
order year 
save "$results/mp_uni_us.dta",replace 
