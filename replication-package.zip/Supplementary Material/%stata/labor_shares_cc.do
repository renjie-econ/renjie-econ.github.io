********************************************************************************
* Input: country-year household census and surveys from IPUMS-I
* Output: labor shares of own-account workers and employers across countries  
********************************************************************************

clear all 
set more off, perm
set scheme s2mono

global data  "~/data/ipums_i"
global results  "~/results"

clear

cd $data
local cid=0
foreach file in "argentina_1970"	"argentina_1980"	"argentina_1991"	"argentina_2001"	"austria_2011"	"bangladesh_1991"	"bangladesh_2001"	"armenia_2001"	"armenia_2011"	"bolivia_1976"	"bolivia_1992"	"bolivia_2001"	"botswana_2001"	"botswana_2011"	"brazil_1960"	"brazil_1970"	"brazil_1980"	"brazil_1991"	"brazil_2000"	"brazil_2010"	"belarus_1999"	"belarus_2009"	"cambodia_1998"	"cambodia_2004"	"cambodia_2008"	"cambodia_2013"	"cameroon_1976"	"cameroon_1987"	"cameroon_2005"	"canada_1981"	"canada_1991"	"canada_2001"	"chile_1960"	"chile_1970"	"chile_1982"	"chile_1992"	"chile_2002"	"colombia_1973"	"colombia_1985"	"colombia_1993"	"colombia_2005"	"costa_rica_1973"	"costa_rica_1984"	"costa_rica_2000"	"costa_rica_2011"	"benin_1979"	"benin_1992"	"benin_2002"	"benin_2013"	"dominican_republic_1960"	"dominican_republic_1970"	"dominican_republic_1981"	"dominican_republic_2002"	"dominican_republic_2010"	"ecuador_1962"	"ecuador_1974"	"ecuador_1982"	"ecuador_1990"	"ecuador_2001"	"ecuador_2010"	"el_salvador_1992"	"el_salvador_2007"	"ethiopia_1984"	"ethiopia_1994"	"ethiopia_2007"	"fiji_1976"	"fiji_2007"	"fiji_2014"	"france_1962"	"france_1968"	"france_1975"	"france_1982"	"france_1990"	"france_1999"	"france_2006"	"france_2011"	"palestine_1997"	"palestine_2007"	"germany_west_1987"	"ghana_1984"	"ghana_2000"	"ghana_2010"	"greece_1971"	"greece_1981"	"greece_1991"	"greece_2001"	"greece_2011"	"guatemala_1964"	"guatemala_1973"	"guatemala_1981"	"guatemala_1994"	"guatemala_2002"	"guinea_1983"	"guinea_1996"	"haiti_1971"	"haiti_1982"	"haiti_2003"	"honduras_1961"	"honduras_1974"	"honduras_1988"	"honduras_2001"	"india_1993"	"india_1999"	"india_2004"	"india_2009"	"indonesia_1971"	"indonesia_1976"	"indonesia_1980"	"indonesia_1985"	"indonesia_1990"	"indonesia_1995"	"indonesia_2000"	"indonesia_2005"	"indonesia_2010"	"iran_2006"	"iran_2011"	"iraq_1997"	"ireland_1971"	"ireland_1981"	"ireland_1986"	"ireland_1991"	"ireland_1996"	"ireland_2002"	"ireland_2006"	"ireland_2011"	"israel_1972"	"israel_1983"	"israel_1995"	"italy_2001"	"italy_2011"	"jamaica_1982"	"jamaica_1991"	"jamaica_2001"	"jordan_2004"	"kyrgyz_republic_1999"	"laos_2005"	"lesotho_1996"	"lesotho_2006"	"liberia_1974"	"liberia_2008"	"malawi_1987"	"malawi_1998"	"malawi_2008"	"malaysia_1970"	"malaysia_1980"	"malaysia_1991"	"malaysia_2000"	"mali_1987"	"mali_1998"	"mali_2009"	"mexico_1970"	"mexico_1990"	"mexico_1995"	"mexico_2000"	"mexico_2010"	"mexico_2015"	"mongolia_2000"	"morocco_1982"	"morocco_1994"	"morocco_2004"	"nepal_2001"	"nepal_2011"	"nicaragua_1971"	"nicaragua_1995"	"nicaragua_2005"	"nigeria_2006"	"nigeria_2007"	"nigeria_2008"	"nigeria_2009"	"pakistan_1973"	"panama_1960"	"panama_1970"	"panama_1980"	"panama_1990"	"panama_2000"	"panama_2010"	"paraguay_1962"	"paraguay_1972"	"paraguay_1982"	"paraguay_1992"	"paraguay_2002"	"peru_1993"	"peru_2007"	"philippines_1995"	"philippines_2000"	"philippines_2010"	"poland_2002"	"portugal_1981"	"portugal_1991"	"portugal_2001"	"portugal_2011"	"romania_1992"	"romania_2002"	"russia_2002"	"russia_2010"	"rwanda_1991"	"rwanda_2002"	"rwanda_2012"	"senegal_1988"	"senegal_2002"	"south_africa_1996"	"south_africa_2001"	"south_africa_2007"	"spain_1981"	"spain_1991"	"spain_2001"	"spain_2011"	"sudan_2008"	"switzerland_2000"	"thailand_1970"	"thailand_1980"	"thailand_1990"	"thailand_2000"	"togo_1970"	"togo_2010"	"trinidad_and_tobago_1970"	"trinidad_and_tobago_1980"	"trinidad_and_tobago_1990"	"trinidad_and_tobago_2000"	"trinidad_and_tobago_2011"	"turkey_1985"	"turkey_1990"	"turkey_2000"	"egypt_1986"	"egypt_1996"	"egypt_2006"	"united_kingdom_1991"	"united_kingdom_2001"	"tanzania_1988"	"tanzania_2002"	"tanzania_2012"	"burkina_faso_1985"	"burkina_faso_1996"	"burkina_faso_2006"	"uruguay_1963"	"uruguay_1975"	"uruguay_1985"	"uruguay_1996"	"uruguay_2006"	"venezuela_1971"	"venezuela_1981"	"venezuela_1990"	"venezuela_2001"	"zambia_1990"	"zambia_2000"	"zambia_2010" {

use `file', clear
local ++cid
disp `cid'

qui keep if gq == 10  // Households
qui keep if sex == 1  //Male 
qui keep if age >= 25 & age <= 54 // Prime age

* recode occupations: own-account worker, employer, wage worker
* Note: 1. for Brazil 1980, classwkd=110 are "Sharecropper, employer" who hire employees in the production; 2. for Dominican Republic, classwkd=100 (self-employed) refers to own-account workers. classwkd=100/111 do not appear in other country-year observations
qui gen own=((classwkd<200 & classwkd>111) | classwkd==100) 
qui gen employer=(classwkd==110 | classwkd==111)
qui gen wage=(classwk==2)
qui drop if (own==0 & employer==0 & wage==0)
qui collapse (mean) own employer wage [aw=perwt],by(country year sample)

if `cid'==1 {
	save "$results/labor_shares_cc.dta",replace
}
else {

	append using "$results/labor_shares_cc.dta",nolabel
    save "$results/labor_shares_cc.dta",replace
}
}

********************************************************************************
*                    Average Across Time and Merge with GDP Data	    	   *
********************************************************************************
* merge country-year labor shares with GDP per capita
* data source: PWT 9.1
use "$results/labor_shares_cc.dta",clear

kountry country, from(iso3n) to (iso3c)
* 729: Sudan 834: Tanzania 643:Russia
replace _ISO3C_="SSD" if country==728
replace _ISO3C_="SDN" if country==729 
replace _ISO3C_="TZA" if country==834 
replace _ISO3C_="RUS" if country==643
rename _ISO3C_ countrycode
merge m:1 countrycode year using "~/data/gdppc.dta",keepusing(gdppc ln_gdppc)
keep if _merge==3 
drop _merge

local var_list own employer wage
foreach var of local var_list {
	bysort country: egen `var'_cavg=mean(`var')
}
bysort country: egen mean_gdppc=mean(gdppc) 
gen ln_mean_gdppc=ln(mean_gdppc) 

save "$results/labor_shares_cc.dta",replace 
