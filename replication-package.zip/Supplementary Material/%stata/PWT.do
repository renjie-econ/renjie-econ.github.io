********************************************************************************
* Input: Penn World Table version 9.1
* Output: GDP per capita, capital to output ratio, and countries by three income terciles
********************************************************************************

clear all
set more off
use "~/data/pwt91.dta",clear
drop if year<1960

* GDP per capita 
gen gdppc=rgdpo/pop /* rgdpo:output-side real gdp per capita at chained PPPs (in mil. 2011US$) */
gen ln_gdppc=ln(gdppc) 
drop if ln_gdppc==.

* capital-output ratio
gen k_y_ratio=cn/rgdpo /*cn: Capital stock at current PPPs (in mil. 2011US$) */

save "~/data/gdppc.dta", replace


use "~/data/gdppc.dta",clear
keep countrycode year gdppc ln_gdppc
tempfile temp
save `temp' 
collapse (mean) mean_gdppc=gdppc, by(countrycode)
gen ln_mean_gdppc=ln(mean_gdppc) 
xtile gdppc_tercile=mean_gdppc,nq(3)
sort mean_gdppc
bysort gdppc_tercile: egen gdppc_tercile_cutoff=max(mean_gdppc)
bysort gdppc_tercile: egen lngdppc_tercile_cutoff=max(ln_mean_gdppc)
tab gdppc_tercile_cutoff lngdppc_tercile_cutoff
/*
gdppc_terc |      lngdppc_tercile_cutoff
ile_cutoff |  8.287376   9.429406   12.64446 |     Total
-----------+---------------------------------+----------
  3973.397 |        61          0          0 |        61 
  12449.13 |         0         61          0 |        61 
  310039.7 |         0          0         60 |        60 
-----------+---------------------------------+----------
     Total |        61         61         60 |       182 

*/
save "~/data/gdppc_tercile.dta",replace
