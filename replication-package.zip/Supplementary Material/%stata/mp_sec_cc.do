********************************************************************************
* Input: country-year household census and surveys from IPUMS-I
* Output: multinomial probit estimates on the effect of secondary school completion 
********************************************************************************

clear all 
set more off, perm
set scheme s2mono

global data  "~/data/ipums_i"
global results  "~/results"


clear
cd $data
local cid=0
foreach file in "argentina_1980" "argentina_1991"	"argentina_2001"	"armenia_2001"	"armenia_2011"	"bolivia_1976"	"bolivia_1992"	"bolivia_2001"	"brazil_1960"	"brazil_1970"	"brazil_1980"	"brazil_1991"	"brazil_2000"	"brazil_2010"	"belarus_1999"	"belarus_2009"	"cambodia_1998"	"cambodia_2004"	"cambodia_2008"	"cambodia_2013"	"cameroon_1987"	"cameroon_2005"	"chile_1960"	"chile_1970"	"chile_1982"	"chile_1992"	"chile_2002"	"colombia_1973"	"colombia_1985"	"colombia_1993"	"colombia_2005"	"costa_rica_1973"	"costa_rica_1984"	"costa_rica_2000"	"costa_rica_2011"	"benin_2002"	"benin_2013"	"dominican_republic_1960"	"dominican_republic_1970"	"dominican_republic_2002"	"dominican_republic_2010"	"ecuador_1962"	"ecuador_1990"	"ecuador_2001"	"ecuador_2010"	"el_salvador_2007"	"fiji_2007"	"france_1962"	"france_1968"	"france_1975"	"france_1982"	"france_1990"	"france_1999"	"france_2006"	"france_2011"	"palestine_1997"	"palestine_2007"	"ghana_2000"	"ghana_2010"	"guatemala_1964"	"guatemala_1973"	"guatemala_1981"	"guatemala_1994"	"guatemala_2002"	"guinea_1983"	"guinea_1996"	"haiti_2003"	"honduras_1974"	"honduras_1988"	"honduras_2001"	"indonesia_1971"	"indonesia_1976"	"indonesia_1980"	"indonesia_1985"	"indonesia_1990"	"indonesia_1995"	"indonesia_2000"	"indonesia_2005"	"indonesia_2010"	"iran_2006"	"iran_2011"	"iraq_1997"	"ireland_1991"	"ireland_1996"	"ireland_2002"	"ireland_2006"	"ireland_2011"	"israel_1983"	"israel_1995"	"jamaica_2001"	"kyrgyz_republic_1999"	"laos_2005"	"lesotho_1996"	"lesotho_2006"	"liberia_1974"	"liberia_2008"	"malawi_1987"	"malawi_1998"	"malawi_2008"	"malaysia_1970"	"malaysia_1980"	"malaysia_1991"	"malaysia_2000"	"mali_1998"	"mali_2009"	"mexico_1970"	"mexico_1990"	"mexico_1995"	"mexico_2000"	"mexico_2010"	"mexico_2015"	"nepal_2001"	"nepal_2011"	"nicaragua_2005"	"pakistan_1973"	"panama_1960"	"panama_1970"	"panama_1980"	"panama_2000"	"panama_2010"	"paraguay_1962"	"paraguay_1972"	"paraguay_1982"	"paraguay_1992"	"paraguay_2002"	"peru_1993"	"peru_2007"	"poland_2002"	"portugal_1981"	"portugal_1991"	"portugal_2001"	"portugal_2011"	"romania_1992"	"romania_2002"	"russia_2002"	"russia_2010"	"rwanda_2002"	"rwanda_2012"	"senegal_2002"	"south_africa_1996"	"south_africa_2001"	"south_africa_2007"	"spain_1981"	"sudan_2008"	"thailand_1970"	"thailand_1980"	"thailand_1990"	"thailand_2000"	"togo_2010"	"egypt_1986"	"egypt_1996"	"egypt_2006"	"tanzania_2002"	"tanzania_2012"	"burkina_faso_2006"	"uruguay_1963"	"uruguay_1975"	"uruguay_1985"	"venezuela_1981"	"venezuela_1990"	"venezuela_2001"	"zambia_1990"	"zambia_2000" 	{

use `file', clear
local ++cid
disp `cid'

qui keep if gq == 10  // Households
qui keep if sex == 1  //Male 
qui keep if age >= 25 & age <= 54 // Prime age

local country_local=country[1]
local year_local=year[1]

* nativity: 0	NIU (not universe); 1 Native-born;2 Foreign-born; 9 Unknown/missing ==> 0 foreign-born; 1 native-born
qui drop if nativity==0 | nativity==9 | nativity==.
qui replace nativity=0 if nativity==2 
qui gen age2=age^2

* ruban: 1 Rural; 2 Urban; 9 Unknown ==> 0 Rural; 1 Urban
qui drop if urban==9 | urban==.
qui replace urban=0 if urban==1
qui replace urban=1 if urban==2

* edattain: 0 NIU; 1 less than primary completed; 2 primary completed;3 secondary completed; 4 university completed;9 Unknown
qui drop if edattain==0 | edattain==9 | edattain==.
* 0 Not secondary completed; 1 secondary completed
qui gen sec=0
qui replace sec=1 if edattain==3 | edattain==4

*** Multinomia Choice: 0=own-account worker, 1=employer, 2=wage worker  
* Note: 1. for Brazil 1980, classwkd=110 are "Sharecropper, employer" who hire employees in the production; 2. for Dominican Republic, classwkd=100 (self-employed) refers to own-account workers. classwkd=100/111 do not appear in other country-year observations
qui gen job=.
qui replace job=0 if ((classwkd<200 & classwkd>111) | classwkd==100)
qui replace job=1 if (classwkd==110 | classwkd==111)
qui replace job=2 if classwk==2
qui drop if job==.
qui label define joblabel 0 "own-account" 1 "employer" 2 "wage"
qui label values job joblabel

qui keep job sec age age2 nativity urban perwt
mprobit job i.sec age age2 nativity urban [pw=perwt], robust
margins sec [pw=perwt],coeflegend post

* the effect of "secondary completed" on the choice of being a own-account worker
quietly lincomest _b[1bn._predict#1.sec]-_b[1bn._predict#0bn.sec],holdname(own) 
parmest, norestore
drop parm
rename * =_own
gen country=`country_local'
gen year=`year_local'
tempfile temp 
save `temp',replace

_estimates unhold own

* the effect of "secondary completed" on the choice of being an employer
quietly lincomest _b[2._predict#1.sec]-_b[2._predict#0bn.sec]
parmest, norestore
drop parm
rename * =_employer
gen country=`country_local'
gen year=`year_local'
merge 1:1 country year using `temp'
drop _merge 

if `cid'==1 {
save "$results/mp_sec_cc.dta",replace
}
else {
append using "$results/mp_sec_cc.dta",nolabel
save "$results/mp_sec_cc.dta",replace
}
}

********************************************************************************
*                           Merge with GDP Data	    	                       *
********************************************************************************
* merge with GDP per capita
* data source: PWT 9.1
use "$results/mp_sec_cc",clear
kountry country, from(iso3n) to (iso3c)
* 729: Sudan 834: Tanzania 643:Russia
replace _ISO3C_="SSD" if country==728
replace _ISO3C_="SDN" if country==729 
replace _ISO3C_="TZA" if country==834 
replace _ISO3C_="RUS" if country==643
rename _ISO3C_ countrycode
merge m:1 countrycode year using "~/data/gdppc.dta",keepusing(gdppc ln_gdppc)
keep if _merge==3 
drop _merge country 
order countrycode year 
save "$results/mp_sec_cc.dta",replace 
