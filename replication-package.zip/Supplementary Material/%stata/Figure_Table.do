********************************************************************************
* Input: empirical and quantitative results
* Output: generate figures and tables 
********************************************************************************
clear all 
set more off, perm
set scheme s2mono

global results  "~/results"
global figures  "~/figures"
global data  "~/data"

clear

********************************************************************************
*Figure 1 (shares_cavg): Labor Force Shares by Self-employment Type Across Countries *
********************************************************************************
use "$results/labor_shares_cc.dta",clear 
keep countrycode ln_mean_gdppc own_cavg employer_cavg 
duplicates drop

foreach x of var own_cavg employer_cavg{
replace `x' = 100 * `x'
format `x' %9.0f
}

twoway (lfit own_cavg ln_mean_gdppc) (scatter own_cavg ln_mean_gdppc,mlabel(countrycode) msize(vsmall)), legend(off) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Own-Account Workers (%)") graphregion(fcolor(white) lcolor(white))
graph export "$figures/own_share_cavg.pdf", as(pdf) replace 

twoway (lfit employer_cavg ln_mean_gdppc) (scatter employer_cavg ln_mean_gdppc,mlabel(countrycode) msize(vsmall)), legend(off) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Employers (%)") graphregion(fcolor(white) lcolor(white))
graph export "$figures/employer_share_cavg.pdf", as(pdf) replace


********************************************************************************
* Table 1 (lf_coef):Slope Coefficients of Labor Shares (%) on Income per capita *
********************************************************************************
use "$results/labor_shares_cc.dta",clear 
foreach x of var own* employer* {
replace `x' = 100 * `x'
}
reg own ln_gdppc,r
est store own_share_cy
reg employer ln_gdppc,r
est store employer_share_cy

duplicates drop countrycode,force
reg own_cavg ln_mean_gdppc,r
est store own_share_cavg
reg employer_cavg ln_mean_gdppc,r
est store employer_share_cavg

esttab own_share_cy employer_share_cy own_share_cavg employer_share_cavg, b(%9.2f) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 ) 
/*
----------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)   
                      own        employer        own_cavg    employer_c~g   
----------------------------------------------------------------------------
ln_gdppc           -19.16***         1.59***                                
                   (0.85)          (0.14)                                   

ln_mean_gd~c                                       -19.74***         1.35***
                                                   (1.49)          (0.22)   

_cons              204.07***        -9.43***       208.74***        -7.50***
                   (7.70)          (1.21)         (13.36)          (1.90)   
----------------------------------------------------------------------------
N                     246             246              77              77   
R-sq                 0.63            0.28            0.64            0.25   
----------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/
estout own_share_cy employer_share_cy own_share_cavg employer_share_cavg, style(tex) cells(b(star fmt(2)) se(par)) stats(r2 N, fmt(%9.2f %09.0g) labels(R$^2$)) legend label starlevels(* 0.10 ** 0.05 *** 0.01 )

********************************************************************************
* Table 2 (lf_coef):Slope Coefficients of Labor Shares (%) on Income per capita by Sector *
********************************************************************************
use "$results/labor_shares_sector_cc.dta",clear 
duplicates drop countrycode sector,force
foreach x of var *cavg {
replace `x' = 100 * `x'
}

foreach i of numlist 1 2 3 {
	if `i'==1 {
		local sec="agri"
	}
	else if `i'==2 {
		local sec="manu"
	}
	else {
		local sec="serv"
	}
	reg own_cavg ln_mean_gdppc if sector==`i',r
    est store `sec'_own_share_cavg
    reg employer_cavg ln_mean_gdppc if sector==`i',r
    est store `sec'_employer_share_cavg

}
esttab agri_own_share_cavg agri_employer_share_cavg manu_own_share_cavg manu_employer_share_cavg serv_own_share_cavg serv_employer_share_cavg, b(%9.2f) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 ) 
/*
------------------------------------------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)             (5)             (6)   
                 own_cavg    employer_c~g        own_cavg    employer_c~g        own_cavg    employer_c~g   
------------------------------------------------------------------------------------------------------------
ln_mean_gd~c       -13.63***         2.34***       -13.27***         1.11***       -11.94***         1.92***
                   (2.58)          (0.63)          (1.78)          (0.22)          (1.13)          (0.27)   

_cons              180.35***       -14.97***       138.29***        -5.49***       134.11***       -11.34***
                  (21.71)          (5.23)         (16.41)          (1.91)          (9.93)          (2.32)   
------------------------------------------------------------------------------------------------------------
N                      75              75              75              75              75              75   
R-sq                 0.26            0.19            0.44            0.21            0.54            0.35   
------------------------------------------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/
estout agri_own_share_cavg agri_employer_share_cavg manu_own_share_cavg manu_employer_share_cavg serv_own_share_cavg serv_employer_share_cavg, style(tex) cells(b(star fmt(2)) se(par)) stats(r2 N, fmt(%9.2f %09.0g) labels(R$^2$)) legend label starlevels(* 0.10 ** 0.05 *** 0.01 )

********************************************************************************
* Figure 2 (mp_yrs):Selection on Years of Schooling into Own-account Workers/Employers *
********************************************************************************
use "$results/mp_yrs_cc.dta",clear
twoway (rcap ci_lower_own ci_upper_own ln_gdppc, lcolor(gs12)) (lfit coef_own  ln_gdppc, lcolor(maroon) lpattern(dash)) (scatter coef_own  ln_gdppc,  yline(0, lcolor(gs9)) msymbol(O) mcolor(maroon) msize(small) lcolor(black)  mlabcolor(edkblue)) (rcap ci_lower_employer ci_upper_employer  ln_gdppc, lcolor(gs12)) (lfit coef_employer  ln_gdppc, lcolor(black) lpattern(dash)) (scatter coef_employer  ln_gdppc,  mcolor(black) msize(small) msymbol(t) mlabcolor(edkblue)),graphregion(fcolor(white) lcolor(white) lstyle(black)) ytitle("Average Marginal Effect of Schooling Years")   xtitle("ln (GDP per capita)") text(0.008 6.7 "Employer") text(-0.035 9.5  "Own-account worker",color(maroon)) xlabel(6 (1) 10) legend(off)
graph export "$figures/mp_yrs.pdf", as(pdf) replace 

********************************************************************************
/* Figure 5 (own_predict):Labor Force Shares of Own-Account Workers in Model and Data
  Figure 6 (employer_predict):Labor Force Shares of Own-Account Workers in Model and Data */
********************************************************************************
use "$results/labor_shares_cc",clear
gen data=1
duplicates drop countrycode,force 
append using "$results/model_predict"
foreach x of var own* employer*{
replace `x' = 100 * `x'
format `x' %9.0f
}
graph twoway (scatter own_cavg ln_mean_gdppc if data==1,mlabel(countrycode) msymbol(O) mcolor(gs0) msize(vsmall) mlabsize(vsmall)) (connected own ln_gdppc if am==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) (connected own ln_gdppc if phi==1, msymbol(triangle) mcolor(dkgreen) msize(small) lcolor(dkgreen) lpattern("_")) (connected own ln_gdppc if amphi==1, msymbol(square) mcolor(gs0) msize(small) lcolor(gs0) ),  legend(order(1 "country average data" 4 "model varying {it:A{sub:M}} and {it:{&phi}}" 2 "model varying {it:A{sub:M}}" 3 "model varying {it:{&phi}}" )) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Own-account Workers (%)") graphregion(fcolor(white) lcolor(white))
graph export "$figures/own_share_predict.pdf", as(pdf) replace 

graph twoway (scatter employer_cavg ln_mean_gdppc if data==1,mlabel(countrycode) msymbol(O) mcolor(gs0) msize(vsmall) mlabsize(vsmall)) (connected employer ln_gdppc if am==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) (connected employer ln_gdppc if phi==1, msymbol(triangle) mcolor(dkgreen) msize(small) lcolor(dkgreen) lpattern("_")) (connected employer ln_gdppc if amphi==1, msymbol(square) mcolor(gs0) msize(small) lcolor(gs0)),  legend(order(1 "country average data" 4 "model varying {it:A{sub:M}} and {it:{&phi}}" 2 "model varying {it:A{sub:M}}" 3 "model varying {it:{&phi}}" )) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Employers (%)") graphregion(fcolor(white) lcolor(white) lstyle(gs0))
graph export "$figures/employer_share_predict.pdf", as(pdf) replace

********************************************************************************
* Figure 7 (selection_predict):Average Ability of Own-account Workers and Employers in Model*
********************************************************************************
use "$results/model_predict",clear
graph twoway (connected avg_h_o ln_gdppc if am==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) (connected avg_h_o ln_gdppc if phi==1, msymbol(triangle) mcolor(dkgreen) msize(small) lcolor(dkgreen) lpattern("_")) (connected avg_h_o ln_gdppc if amphi==1, msymbol(square) mcolor(black) msize(small) lcolor(black) ) (connected avg_h_e ln_gdppc if am==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) (connected avg_h_e ln_gdppc if phi==1, msymbol(triangle) mcolor(dkgreen) msize(small) lcolor(dkgreen) lpattern("_")) (connected avg_h_e ln_gdppc if amphi==1, msymbol(square) mcolor(gs0) msize(small) lcolor(gs0) ),  yline(1) legend(order(3 "model varying {it:A{sub:M}} and {it:{&phi}}" 1 "model varying {it:A{sub:M}}" 2 "model varying {it:{&phi}}" ))scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Average Ability") graphregion(fcolor(white) lcolor(white) lstyle(black)) text(1.1 10.5 "Wage Worker") text(0.7 10.5 "Own-account Worker") text(2.3 9.5 "Employer")
graph export "$figures/selection_predict.pdf", as(pdf) replace 


********************************************************************************
* Figure 8 (d_to_gdp_predict):Private Debt to GDP Ratios in Model and Data *
********************************************************************************
import excel "$data/FinancialStructureDatabase20191018.xlsx", sheet("Data - October 2019") cellrange(A2:AJ12414) firstrow clear
rename cncode countrycode
merge 1:1 countrycode year using "/Users/rj/Desktop/entrepreneurship/empirical/data/gdppc.dta",keepusing(gdppc ln_gdppc)
keep if _merge==3
drop _merge 
drop if pcrdbofgdp==.
gen d_to_gdp=pcrdbofgdp+prbond+stmktcap*0.33
keep if d_to_gdp~=.
gen data=1
append using "$results/model_predict"
graph twoway (scatter d_to_gdp ln_gdppc if data==1, msymbol(O) mcolor(gs10) msize(vsmall)) (lfit d_to_gdp ln_gdppc if data==1, msymbol(O) lcolor(gs10) msize(vsmall))(connected d_to_gdp ln_gdppc if am==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) (connected d_to_gdp ln_gdppc if phi==1, msymbol(triangle) mcolor(dkgreen) msize(small) lcolor(dkgreen) lpattern("_")) (connected d_to_gdp ln_gdppc if amphi==1, msymbol(square) lcolor(gs0) msize(small) mcolor(gs0) ),  legend(order(1 "country-year data" 5 "model varying {it:A{sub:M}} and {it:{&phi}}" 3 "model varying {it:A{sub:M}}" 4 "model varying {it:{&phi}}" ))scheme(s2mono) ytitle("Private Debt to GDP Ratio (%)") xtitle("ln (GDP per capita)") graphregion(fcolor(white) lcolor(white)) xlabel(7(1)11)
graph export "$figures/d_to_gdp_predict.pdf", as(pdf) replace 

********************************************************************************
* Figure 9 (impact_fin): Effects of Removing Financial Frictions *
********************************************************************************
use "$results/model_fin_effect",clear

* Change in Share of Own-Account Workers (p.p.) 
graph twoway (connected own_share ln_gdppc,msymbol(square) lcolor(gs0) msize(small) mcolor(gs0)) (connected own_share5 ln_gdppc, msize(tiny) lpattern("_")) (connected own_share3 ln_gdppc, msize(tiny) lpattern("_-"))(connected own_share22 ln_gdppc, msize(tiny) lpattern("_."))(connected own_share19 ln_gdppc, msize(tiny) lpattern("-."))(connected own_share17 ln_gdppc, msize(tiny) lpattern("-"))(connected own_share15 ln_gdppc, msize(tiny) lpattern("."))(connected own_share137 ln_gdppc, msize(tiny) lpattern("_-.")) (connected own_share125 ln_gdppc, msize(tiny) lpattern("_..")) (connected own_share115 ln_gdppc, msize(tiny) lpattern("-..")),   scheme(s2color)  xtitle("ln (GDP per capita)") xline(8.3 9.4, lpattern("-") lcolor(gs5)) yline(0, lcolor(gs12))graphregion(fcolor(white) lcolor(white) lstyle(black)) legend(off)
graph export "$figures/own_share_fin.pdf", as(pdf) replace

* Change in Share of Employers (p.p.)
graph twoway (connected employer_share ln_gdppc,msymbol(square) lcolor(gs0) msize(small) mcolor(gs0)) (connected employer_share5 ln_gdppc, msize(tiny) lpattern("_")) (connected employer_share3 ln_gdppc, msize(tiny) lpattern("_-"))(connected employer_share22 ln_gdppc, msize(tiny) lpattern("_."))(connected employer_share19 ln_gdppc, msize(tiny) lpattern("-."))(connected employer_share17 ln_gdppc, msize(tiny) lpattern("-"))(connected employer_share15 ln_gdppc, msize(tiny) lpattern("."))(connected employer_share137 ln_gdppc, msize(tiny) lpattern("_-.")) (connected employer_share125 ln_gdppc,msize(tiny) lpattern("_..")) (connected employer_share115 ln_gdppc,msize(tiny) lpattern("-..")),  legend(pos(2) ring(0) col(2) label(1 "benchmark") label(2 "{it:{&phi}}=5") label(3 "{it:{&phi}}=3") label(4 "{it:{&phi}}=2.2") label(5 "{it:{&phi}}=1.9") label(6 "{it:{&phi}}=1.7") label(7 "{it:{&phi}}=1.5") label(8 "{it:{&phi}}=1.37") label(9 "{it:{&phi}}=1.25") label(10 "{it:{&phi}}=1.15")) scheme(s2color)  xtitle("ln (GDP per capita)") xline(8.3 9.4, lpattern("-") lcolor(gs5))yline(0, lcolor(gs12)) graphregion(fcolor(white) lcolor(white))
graph export "$figures/emp_share_fin.pdf", as(pdf) replace

* Change in Modern Sector TFP (%)
graph twoway (connected tfp_m ln_gdppc,msymbol(square) lcolor(gs0) msize(small) mcolor(gs0)) (connected tfp_m5 ln_gdppc, msize(tiny) lpattern("_")) (connected tfp_m3 ln_gdppc, msize(tiny) lpattern("_-"))(connected tfp_m22 ln_gdppc, msize(tiny) lpattern("_."))(connected tfp_m19 ln_gdppc, msize(tiny) lpattern("-."))(connected tfp_m17 ln_gdppc, msize(tiny) lpattern("-"))(connected tfp_m15 ln_gdppc, msize(tiny) lpattern("."))(connected tfp_m137 ln_gdppc, msize(tiny) lpattern("_-.")) (connected tfp_m125 ln_gdppc, msize(tiny) lpattern("_..")) (connected tfp_m115 ln_gdppc, msize(tiny) lpattern("-..")),  scheme(s2color)  xtitle("ln (GDP per capita)") xline(8.3 9.4, lpattern("-") lcolor(gs5)) graphregion(fcolor(white) lcolor(white)) legend(off)
graph export "$figures/tfpm_fin.pdf", as(pdf) replace

* Change in GDP per capita (%) 
graph twoway (connected gdppc ln_gdppc,msymbol(square) mcolor(gs0) msize(small) lcolor(gs0)) (connected gdppc5 ln_gdppc, msize(tiny) lpattern("_")) (connected gdppc3 ln_gdppc, msize(tiny) lpattern("_-"))(connected gdppc22 ln_gdppc, msize(tiny) lpattern("_."))(connected gdppc19 ln_gdppc, msize(tiny) lpattern("-."))(connected gdppc17 ln_gdppc, msize(tiny) lpattern("-"))(connected gdppc15 ln_gdppc, msize(tiny) lpattern("."))(connected gdppc137 ln_gdppc, msize(tiny) lpattern("_-.")) (connected gdppc125 ln_gdppc, msize(tiny) lpattern("_..")) (connected gdppc115 ln_gdppc, msize(tiny) lpattern("-..")), scheme(s2color)  xtitle("ln (GDP per capita)") xline(8.3 9.4, lpattern("-") lcolor(gs5)) graphregion(fcolor(white) lcolor(white)) legend(off)
graph export "$figures/gdppc_fin.pdf", as(pdf) replace

********************************************************************************
* Figure 10 (compare): Removing Financial Frictions in Model with Skill-neutral Technological Change *
********************************************************************************
use "$results/model_SBTC_SNTC",clear
gen gdp_inc=(ln_gdppc_inf-ln_gdppc)*100
gen tfp_m_inc=(tfp_m_inf/tfp_m-1)*100

* Change in Modern Sector TFP (%)
graph twoway (connected tfp_m_inc ln_gdppc if SBTC==1, msymbol(square) mcolor(gs0) msize(small) lcolor(gs0))(connected tfp_m_inc ln_gdppc if SNTC==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) , legend(pos(2) ring(0) col(1) label(1 "skill-biased") label(2 "skill-neutral")) scheme(s2color)  xtitle("ln (GDP per capita)") xline(8.3 9.4, lpattern("-") lcolor(gs5)) graphregion(fcolor(white) lcolor(white))  ytitle("")
graph export "$figures/compare_tfpm.pdf", as(pdf) replace

* Change in GDP per capita (%)
graph twoway (connected gdp_inc ln_gdppc if SBTC==1, msymbol(square) mcolor(gs0) msize(small) lcolor(gs0))(connected gdp_inc ln_gdppc if SNTC==1, msymbol(O) mcolor(maroon) msize(small) lcolor(maroon) lpattern("-.")) ,  scheme(s2color)  xtitle("ln (GDP per capita)") xline(8.3 9.4, lpattern("-") lcolor(gs5)) graphregion(fcolor(white) lcolor(white)) ytitle("") legend(off)
graph export "$figures/compare_gdp.pdf", as(pdf) replace

********************************************************************************
* Figure A1 (share_sectors):Labor Shares of Own-account Workers and Employers, by Sector*
********************************************************************************
use "$results/labor_shares_sector_cc.dta",clear 
duplicates drop countrycode sector,force
foreach x of var *cavg {
replace `x' = 100 * `x'
}

foreach i of numlist 1 2 3 {
	if `i'==1 {
		local sec="agri"
	}
	else if `i'==2 {
		local sec="manu"
	}
	else {
		local sec="serv"
	}

twoway (lfit own_cavg ln_mean_gdppc if sector==`i') (scatter own_cavg ln_mean_gdppc if sector==`i',mlabel(countrycode) msize(vsmall)), legend(off) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Own-Account Workers (%)") graphregion(fcolor(white) lcolor(white))
graph export "$figures/own_share_cavg_`sec'.pdf", as(pdf) replace 

twoway (lfit employer_cavg ln_mean_gdppc if sector==`i') (scatter employer_cavg ln_mean_gdppc if sector==`i',mlabel(countrycode) msize(vsmall)), legend(off) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Employers (%)") graphregion(fcolor(white) lcolor(white))
graph export "$figures/employer_share_cavg_`sec'.pdf", as(pdf) replace
}

********************************************************************************
* Figure A2 (mp_sec):Selection on Secondary School Completion into Own-account Workers/Employers*
********************************************************************************
use "$results/mp_sec_cc",clear
twoway (rcap min95_own max95_own ln_gdppc, lcolor(gs12)) (lfit estimate_own  ln_gdppc, lcolor(maroon) lpattern(dash)) (scatter estimate_own  ln_gdppc,  yline(0, lcolor(gs9))  msymbol(O) mcolor(maroon) msize(small) lcolor(black)  mlabcolor(edkblue)) (rcap min95_employer max95_employer  ln_gdppc, lcolor(gs12)) (lfit estimate_employer  ln_gdppc, lcolor(black) lpattern(dash)) (scatter estimate_employer  ln_gdppc,  mcolor(black) msize(small) msymbol(t) mlabcolor(edkblue)),graphregion(fcolor(white) lcolor(white) lstyle(black)) ytitle("Average Marginal Effect of Secondary School Completion", size(medsmall)) xtitle("ln (GDP per capita)")   xlabel(6 (1) 10) legend(off) text(0.15 6.7 "Employer") text(-0.55 9.5  "Own-account worker",color(maroon))
graph export "$figures/mp_sec.pdf", as(pdf) replace 


******************************************************************************** 
* Table A2 (share_fe):Labor Shares of Own-account Workers and Employers, 
*                          with/without Country and/or Decade Fixed Effects*
********************************************************************************
use "$results/labor_shares_cc",clear
foreach x of var own employer {
replace `x' = 100 * `x'
}
sum year
/*
   Variable |        Obs        Mean    Std. Dev.       Min        Max
-------------+---------------------------------------------------------
        year |        246    1992.821    13.98018       1960       2015

*/
egen decade=cut(year),at(1960,1970,1980,1990,2000,2010,2020)

qui reg own ln_gdppc,r
qui est store own
qui reg own ln_gdppc i.country,r
qui est store own_c
qui reg own ln_gdppc i.decade,r
qui est store own_d
qui reg own ln_gdppc i.country i.decade,r
qui est store own_cd

qui reg employer ln_gdppc,r
qui est store employer
qui reg employer ln_gdppc i.country,r
qui est store employer_c
qui reg employer ln_gdppc i.decade,r
qui est store employer_d
qui reg employer ln_gdppc i.country i.decade,r
qui est store employer_cd

esttab own own_c own_d own_cd employer employer_c employer_d employer_cd, keep(ln_gdppc) b(%9.2f) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 ) 
/*

--------------------------------------------------------------------------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)             (5)             (6)             (7)             (8)   
                      own             own             own             own        employer        employer        employer        employer   
--------------------------------------------------------------------------------------------------------------------------------------------
ln_gdppc           -19.16***        -8.40***       -20.02***        -8.01***         1.59***         1.05***         1.67***         0.40   
                   (0.85)          (1.15)          (0.84)          (1.80)          (0.14)          (0.37)          (0.14)          (0.52)   
--------------------------------------------------------------------------------------------------------------------------------------------
N                     246             246             246             246             246             246             246             246   
R-sq                 0.63            0.95            0.66            0.95            0.28            0.71            0.29            0.74   
--------------------------------------------------------------------------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/
estout own own_c own_d own_cd employer employer_c employer_d employer_cd, keep(ln_gdppc) style(tex) cells(b(star fmt(2)) se(par)) stats(r2 N, fmt(%9.2f %09.0g) labels(R$^2$)) legend label starlevels(* 0.10 ** 0.05 *** 0.01 )

******************************************************************************** 
* Table A3 (us): Labor Force Division and Selection of the U.S. Time Series*
********************************************************************************
* Panel A
use "$results/labor_shares_us",clear
keep if inlist(year,1970,1980,1990,2000,1)
foreach x of var *share *gap {
replace `x' = 100 * `x'
format `x' %9.2f
}
order year 
sort year 
list year un*share un*gap un*pvalue in*share in*gap in*pvalue
/*
       +------------------------------------------------------------------------+
     | year   uninc~re   uninco~p   uninc~ue   incor~re   incor_~p   incor~ue |
     |------------------------------------------------------------------------|
  1. |    1       7.11      -2.44          0       4.29       2.13          0 |
  2. | 1970       9.56          .          .       2.16          .          . |
  3. | 1980       9.10      -0.46   2.10e-28       3.28       1.12          0 |
  4. | 1990       8.25      -1.31          0       3.68       1.52          0 |
  5. | 2000       7.48      -2.07          0       4.21       2.05          0 |
     +------------------------------------------------------------------------+
*/

* Panel B
use "$results/mp_yrs_us",clear
keep if inlist(year,1970,1980,1990,2000,1)
foreach x of var *own *employer {
format `x' %9.4f
}
order year 
sort year 
list year coef_own pval_own coef_employer pval_employer
/*
        +--------------------------------------------------+
     | year   coef_own   pval_own   coef_e~r   pval_e~r |
     |--------------------------------------------------|
  1. |    1    -0.0037     0.0000     0.0037     0.0000 |
  2. | 1970     0.0014     0.0000     0.0029     0.0000 |
  3. | 1980     0.0011     0.0000     0.0044     0.0000 |
  4. | 1990     0.0001     0.1274     0.0037     0.0000 |
  5. | 2000    -0.0015     0.0000     0.0035     0.0000 |
     +--------------------------------------------------+
*/

******************************************************************************** 
* Figure A3 (us_share): Share of Self-employment in the U.S.
********************************************************************************
use "$results/labor_shares_us",clear
drop if year==1
foreach x of var *share {
replace `x' = 100 * `x'
}
graph twoway (lfit un*share ln_gdppc) (scatter un*share ln_gdppc,mlabel(year) msize(tiny)), graphregion(fcolor(white) lcolor(white))legend(off) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Unincorporated Self-employed (%)")
graph export "$figures/unincor_share.pdf", as(pdf) replace 

graph twoway (lfit incor_share ln_gdppc) (scatter incor_share ln_gdppc,mlabel(year) msize(tiny)), graphregion(fcolor(white) lcolor(white)) legend(off) scheme(s2mono) xtitle("ln (GDP per capita)") ytitle("Share of Incorporated Self-employed (%)")
graph export "$figures/incor_share.pdf", as(pdf) replace

******************************************************************************** 
* Figure A4 (mpus_edu): Selection on Education into Unincorporated/Incorporated
********************************************************************************
use "$results/mp_yrs_us",clear
drop if year==1
twoway (rcap ci_lower_own ci_upper_own ln_gdppc, lcolor(gs12)) (lfit coef_own  ln_gdppc, lcolor(maroon) lpattern(dash)) (scatter coef_own  ln_gdppc,  yline(0, lcolor(gs9))  mcolor(maroon) msize(small) lcolor(black)  mlabcolor(edkblue) msymbol(o)) (rcap ci_lower_employer ci_upper_employer  ln_gdppc, lcolor(gs12)) (lfit coef_employer  ln_gdppc, lcolor(black) lpattern(dash)) (scatter coef_employer  ln_gdppc,  mcolor(black) msize(small) msymbol(t) mlabcolor(edkblue)),text(0.005 10.2 "Incorporated") text(-0.002 10.4 "Unincorporated", color(maroon)) graphregion(fcolor(white) lcolor(white)) ytitle("Average Marginal Effect of Schooling Years", size(medsmall)) xtitle("ln (GDP per capita)")   legend(off)
graph export "$figures/mp_yrs_us.pdf", as(pdf) replace 

use "$results/mp_uni_us",clear
twoway (rcap min95_own max95_own ln_gdppc, lcolor(gs12)) (lfit estimate_own  ln_gdppc, lcolor(maroon) lpattern(dash)) (scatter estimate_own  ln_gdppc,  yline(0, lcolor(gs9))  mcolor(maroon) msize(small) lcolor(black)  mlabcolor(edkblue)  msymbol(o)) (rcap min95_employer max95_employer  ln_gdppc, lcolor(gs12)) (lfit estimate_employer  ln_gdppc, lcolor(black) lpattern(dash)) (scatter estimate_employer  ln_gdppc,  mcolor(black) msize(small) msymbol(t) mlabcolor(edkblue)),text(0.03 10.2 "Incorporated") text(-0.02 10.4 "Unincorporated", color(maroon)) graphregion(fcolor(white) lcolor(white))  ytitle("Average Marginal Effect of University Completion", size(medsmall)) xtitle("ln (GDP per capita)")   xlabel(10 (.2) 11) legend(off) 
graph export "$figures/mp_uni_us.pdf", as(pdf) replace 



