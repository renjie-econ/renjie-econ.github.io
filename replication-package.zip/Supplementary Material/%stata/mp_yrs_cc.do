********************************************************************************
* Input: country-year household census and surveys from IPUMS-I
* Output: multinomial probit estimates on the effect of schooling years across countries 
********************************************************************************

clear all 
set more off, perm
set scheme s2mono

global data  "~/data/ipums_i"
global results  "~/results"


clear

cd $data
local cid=0
foreach file in "argentina_1980"	"argentina_1991"	"argentina_2001"	"bolivia_1976"	"bolivia_1992"	"bolivia_2001"	"brazil_1960"	"brazil_1970"	"brazil_1980"	"brazil_1991"	"brazil_2000"	"cambodia_1998"	"cambodia_2004"	"cambodia_2008"	"cambodia_2013"	"cameroon_1987"	"cameroon_2005"	"chile_1960"	"chile_1970"	"chile_1982"	"chile_1992"	"chile_2002"	"colombia_1973"	"colombia_1985"	"colombia_1993"	"colombia_2005"	"costa_rica_1973"	"costa_rica_1984"	"costa_rica_2000"	"costa_rica_2011"	"benin_2002"	"benin_2013"	"dominican_republic_1960"	"dominican_republic_1970"	"dominican_republic_2002"	"dominican_republic_2010"	"ecuador_1962"	"ecuador_1990"	"ecuador_2001"	"ecuador_2010"	"el_salvador_2007"	"fiji_2007"	"palestine_1997"	"ghana_2000"	"ghana_2010"	"guatemala_1964"	"guatemala_1973"	"guatemala_1981"	"guatemala_1994"	"guatemala_2002"	"guinea_1983"	"guinea_1996"	"haiti_2003"	"honduras_1974"	"honduras_1988"	"honduras_2001"	"indonesia_1976"	"indonesia_1980"	"indonesia_1985"	"indonesia_1990"	"indonesia_1995"	"indonesia_2005"	"jamaica_2001"	"laos_2005"	"lesotho_1996"	"lesotho_2006"	"liberia_1974"	"liberia_2008"	"malawi_1987"	"malawi_1998"	"malawi_2008"	"malaysia_1980"	"malaysia_1991"	"mali_1998"	"mali_2009"	"mexico_1970"	"mexico_1990"	"mexico_1995"	"mexico_2000"	"mexico_2010"	"mexico_2015"	"nepal_2001"	"nepal_2011"	"nicaragua_2005"	"panama_1960"	"panama_1970"	"panama_1980"	"panama_2000"	"panama_2010"	"paraguay_1962"	"paraguay_1972"	"paraguay_1982"	"paraguay_1992"	"paraguay_2002"	"peru_1993"	"peru_2007"	"rwanda_2002"	"rwanda_2012"	"senegal_2002"	"south_africa_1996"	"south_africa_2001"	"south_africa_2007"	"thailand_1970"	"thailand_1980"	"thailand_1990"	"thailand_2000"	"togo_2010"	"tanzania_2002"	"tanzania_2012"	"uruguay_1963"	"uruguay_1975"	"uruguay_1985"	"venezuela_1981"	"venezuela_1990"	"venezuela_2001"	"zambia_1990"	"zambia_2000" {

use `file', clear
local ++cid
disp `cid'

qui keep if gq == 10  // Households
qui keep if sex == 1  //Male 
qui keep if age >= 25 & age <= 54 // Prime age

local country_local=country[1]
local year_local=year[1]

* nativity: 0	NIU (not universe); 1 Native-born;2 Foreign-born; 9 Unknown/missing ==> 0 foreign-born; 1 native-born
qui drop if nativity==0 | nativity==9 | nativity==.
qui replace nativity=0 if nativity==2 
qui gen age2=age^2

* ruban: 1 Rural; 2 Urban; 9 Unknown ==> 0 Rural; 1 Urban
qui drop if urban==9 | urban==.
qui replace urban=0 if urban==1
qui replace urban=1 if urban==2

*yrschool: 90 Not specified;91 Some primary;92 Some technical;93 Some secondary;95 Adult literacy;95 Adult literacy;96 Special education; 98 Unknown/missing;99 NIU (not universe)
qui keep if yrschool<=18

*** Multinomia Choice: 0=own-account worker, 1=employer, 2=wage worker  
* Note: 1. for Brazil 1980, classwkd=110 are "Sharecropper, employer" who hire employees in the production; 2. for Dominican Republic, classwkd=100 (self-employed) refers to own-account workers. classwkd=100/111 do not appear in other country-year observations
qui gen job=.
qui replace job=0 if ((classwkd<200 & classwkd>111) | classwkd==100)
qui replace job=1 if (classwkd==110 | classwkd==111)
qui replace job=2 if classwk==2
qui drop if job==.
qui label define joblabel 0 "own-account" 1 "employer" 2 "wage"
qui label values job joblabel

keep job yrschool age age2 nativity urban perwt
mprobit job yrschool age age2 nativity urban [pw=perwt], robust
margins [pw=perwt], dydx(yrschool) coeflegend post

regsave, tstat pva ci
qui gen country=`country_local'
qui gen year=`year_local'

if `cid'==1 {
	save "$results/mp_yrs_cc.dta",replace
}
else {

	append using "$results/mp_yrs_cc.dta",nolabel
    save "$results/mp_yrs_cc.dta",replace
}
}

********************************************************************************
*                    Merge with GDP Data	    	   *
********************************************************************************
* data source: PWT 9.1
use "$results/mp_yrs_cc.dta",clear

preserve
keep if var=="yrschool:2._predict"
drop var
rename * =_employer
rename country_employer country 
rename year_employer year
tempfile temp
save `temp'
restore 

keep if var=="yrschool:1bn._predict"
drop var
rename * =_own
rename country_own country 
rename year_own year
merge 1:1 country year using `temp'
drop _merge 

kountry country, from(iso3n) to (iso3c)
* 729: Sudan 834: Tanzania 643:Russia
replace _ISO3C_="SSD" if country==728
replace _ISO3C_="SDN" if country==729 
replace _ISO3C_="TZA" if country==834 
replace _ISO3C_="RUS" if country==643
rename _ISO3C_ countrycode
merge m:1 countrycode year using "~/data/gdppc.dta",keepusing(gdppc ln_gdppc)
keep if _merge==3 
drop _merge country 
order countrycode year 
save "$results/mp_yrs_cc.dta",replace 
