********************************************************************************
* Input: empirical and quantitative results
* Output: statistics and regression results mentioned in the paper
********************************************************************************
clear all 
set more off, perm

global results  "~/results"
global data  "~/data"

clear

/*----------
      Consistency with Informality
	  Data Source: Informal Economy Database from Elgin et. al (2021)
                                                              ----------------*/

import excel "$data/informal-economy-database.xlsx", sheet("Pension_p") firstrow clear
reshape long pension, i(Economy Code) j(year)
tempfile informal
save `informal'

import excel "$data/informal-economy-database.xlsx", sheet("Infemp_p") firstrow clear
reshape long infemp, i(Economy Code) j(year)
merge 1:1 Code year using `informal'
drop _merge 
save `informal',replace

import excel "$data/informal-economy-database.xlsx", sheet("Infsize_p") firstrow clear
reshape long infsize, i(Economy Code) j(year)
merge 1:1 Code year using `informal'
drop _merge 
drop if infsize==. & infemp==. & pension==.
rename Code countrycode 
merge m:1 countrycode year using "$data/gdppc.dta",keepusing(gdppc ln_gdppc)
keep if _merge==3
drop _merge 
save `informal',replace

sum year
/*
  Variable |        Obs        Mean    Std. Dev.       Min        Max
-------------+---------------------------------------------------------
        year |        677    2006.778    6.913965       1990       2017

*/
egen decade=cut(year),at(1990,2000,2010,2020)
qui reg infsize ln_gdppc i.decade,r
qui est store infsize_d
qui reg infemp ln_gdppc i.decade,r
qui est store infemp_d
qui reg pension ln_gdppc i.decade,r
qui est store pension_d

use "$results/labor_shares_cc.dta",clear
replace own=own*100
egen decade=cut(year),at(1960,1970,1980,1990,2000,2010,2020)
* with decade fixed effect
qui reg own ln_gdppc i.decade,r
qui est store own_d 

esttab infsize_d infemp_d pension_d own_d, keep(ln_gdppc) b(%9.2f) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 ) 
/* 
Regression of informality on log GDP per capital with decade fixed effect
----------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)   
                  infsize          infemp         pension             own   
----------------------------------------------------------------------------
ln_gdppc           -20.02***       -20.78***        25.43***       -20.02***
                   (1.38)          (1.07)          (0.74)          (0.84)   
----------------------------------------------------------------------------
N                     345             329             353             246   
R-sq                 0.52            0.54            0.71            0.66   
----------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/


/*----------
      Robustness check: including "unpaid workers" as own-account workers
                                                              ----------------*/
use "$results/labor_shares_cc.dta",clear 
foreach x of var own* employer* {
replace `x' = 100 * `x'
}
reg own ln_gdppc,r
est store own_share_bk
reg employer ln_gdppc,r
est store employer_share_bk
use "$results/labor_shares_unpaid_cc.dta",clear 
foreach x of var own* employer* {
replace `x' = 100 * `x'
}
reg own ln_gdppc,r
est store own_share_unpaid
reg employer ln_gdppc,r
est store employer_share_unpaid

esttab own_share_unpaid own_share_bk employer_share_unpaid employer_share_bk, keep(ln_gdppc) b(%9.2f) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 ) 
/*
----------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)   
                      own             own        employer        employer   
----------------------------------------------------------------------------
ln_gdppc           -19.72***       -19.16***         1.62***         1.59***
                   (0.82)          (0.85)          (0.14)          (0.14)   
----------------------------------------------------------------------------
N                     246             246             246             246   
R-sq                 0.65            0.63            0.30            0.28   
----------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/

/*----------
      Calibration: estimates for the U.S. moments of labor shares
                                                              ----------------*/
use "$results/labor_shares_cc.dta",clear

* U.S. 2001 GDP per capita: 45,743
* Canada 2001: GDP per capita=36,219, own-account employment=0.0792727, employers' share=0.0650745
sum gdppc,detail
keep if gdppc>=r(p90)
sum gdppc own employer
/*

 Variable |        Obs        Mean    Std. Dev.       Min        Max
-------------+---------------------------------------------------------
       gdppc |         25    31694.28    8179.847   21802.83   50639.73
         own |         25    .1232179    .0507339   .0669186   .2379395
    employer |         25    .0757927     .024382   .0329756   .1406715


*/
														  
/*----------
       Model predictions of labor shares versus data
                                                              ----------------*/

use "$results/labor_shares_cc",clear
gen data=1
duplicates drop countrycode,force 
append using "$results/model_predict"
foreach x of var own* employer*{
replace `x' = 100 * `x'
format `x' %9.0f
}
reg own_cavg ln_mean_gdppc if data==1,r
est store own_share_data
reg own ln_gdppc if amphi==1,r
est store own_share_amphi
reg own ln_gdppc if am==1,r
est store own_share_am
reg own ln_gdppc if phi==1,r
est store own_share_phi

esttab own_share_data own_share_amphi own_share_am own_share_phi, keep(ln_mean_gdppc ln_gdppc) b(2) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 ) 
/*
----------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)   
                 own_cavg             own             own             own   
----------------------------------------------------------------------------
ln_mean_gd~c       -19.74***                                                
                   (1.49)                                                   

ln_gdppc                           -21.38***       -20.58***        -7.91***
                                   (1.59)          (1.52)          (0.58)   
----------------------------------------------------------------------------
N                      77              11              11              11   
R-sq                 0.64            0.97            0.97            0.96   
----------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01

*/

reg employer_cavg ln_mean_gdppc if data==1,r
est store employer_share_data
reg employer ln_gdppc if amphi==1,r
est store employer_share_amphi
reg employer ln_gdppc if am==1,r
est store employer_share_am
reg employer ln_gdppc if phi==1,r
est store employer_share_phi

esttab employer_share_data employer_share_amphi employer_share_am employer_share_phi, keep(ln_mean_gdppc ln_gdppc) b(2) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 )  
/*
-----------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)   
             employer_c~g        employer        employer        employer   
----------------------------------------------------------------------------
ln_mean_gd~c         1.35***                                                
                   (0.22)                                                   

ln_gdppc                             1.45***         1.34***        -7.83***
                                   (0.29)          (0.17)          (0.42)   
----------------------------------------------------------------------------
N                      77              11              11              11   
R-sq                 0.25            0.82            0.92            0.97   
----------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/
/*----------
        Various measures of private Debt to GDP Ratio and model predictions
                                                              ----------------*/
import excel "/Users/rj/Desktop/entrepreneurship/empirical/data/FinancialStructureDatabase20191018.xlsx", sheet("Data - October 2019") cellrange(A2:AJ12414) firstrow clear

rename cncode countrycode
merge 1:1 countrycode year using "/Users/rj/Desktop/entrepreneurship/empirical/data/gdppc.dta",keepusing(gdppc ln_gdppc)
keep if _merge==3
drop _merge 
drop if pcrdbofgdp==.

gen d_to_gdp=pcrdbofgdp+prbond+stmktcap*0.33 //benchmark measure following Buera et. al (2011)
tab incomegr if d_to_gdp~=.
/*
            incomegr |      Freq.     Percent        Cum.
--------------------+-----------------------------------
        High income |        698       67.64       67.64
Lower middle income |         66        6.40       74.03
Upper middle income |        268       25.97      100.00
--------------------+-----------------------------------
              Total |      1,032      100.00

*/
gen capitalization=prbond+stmktcap*0.33
reg capitalization ln_gdppc,r
est store capitalization
esttab capitalization,keep(ln_gdppc) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 )
/*
----------------------------
                      (1)   
             capitaliza~n   
----------------------------
ln_gdppc            29.46***
                   (1.50)     
----------------------------
N                    1032   
R-sq                 0.26   
----------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01

*/

predict pcapitalization
replace capitalization=pcapitalization if capitalization==.
gen d_to_gdp3=pcrdbofgdp+capitalization //measure 3 using imputed capitalization

reg d_to_gdp ln_gdppc,r
est store benchmark  
reg pcrdbofgdp ln_gdppc,r // measure 2: intermediated private credit
est store intermediated_pc
reg d_to_gdp3 ln_gdppc,r 
est store imputed_cap


esttab benchmark intermediated_pc imputed_cap,keep(ln_gdppc) b(2) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 )
/*
------------------------------------------------------------
                      (1)             (2)             (3)   
                 d_to_gdp      pcrdbofgdp       d_to_gdp3   
------------------------------------------------------------
ln_gdppc            64.05***        17.83***        47.29***
                   (2.73)          (0.50)          (0.56)   
------------------------------------------------------------
N                    1032            7761            7761   
R-sq                 0.33            0.26            0.66   
------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01

*/

use "$results/model_predict",clear 
reg d_to_gdp ln_gdppc if amphi==1,r
est store d_to_gdp_amphi 
reg d_to_gdp ln_gdppc if am==1,r
est store d_to_gdp_am
reg d_to_gdp ln_gdppc if phi==1,r
est store d_to_gdp_phi 
esttab d_to_gdp_amphi d_to_gdp_am d_to_gdp_phi ,keep(ln_gdppc) b(2) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 )
/*
------------------------------------------------------------
                      (1)             (2)             (3)   
                 d_to_gdp        d_to_gdp        d_to_gdp   
------------------------------------------------------------
ln_gdppc            60.25***        38.00***        529.93***
                   (1.40)          (6.33)         (26.35)   
------------------------------------------------------------
N                      11              11              11   
R-sq                 1.00            0.87            0.99   
------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/

/*----------
                      Capital to Output Ratio 
                                                              ----------------*/
use "$data/gdppc.dta",clear
sum k_y_ratio,d
gen data=1
append using "/Users/rj/Desktop/entrepreneurship/quant/quant_predict"
reg k_y_ratio ln_gdppc if data==1,r
est store k_y_ratio_data
reg k_y_ratio ln_gdppc if amphi==1,r
est store k_y_ratio_amphi
reg k_y_ratio ln_gdppc if am==1,r
est store k_y_ratio_am
reg k_y_ratio ln_gdppc if phi==1,r
est store k_y_ratio_phi

esttab k_y_ratio_data k_y_ratio_amphi k_y_ratio_am k_y_ratio_phi,keep(ln_gdppc) b(%9.2f) se(%9.2f) r2(%9.2f) starlevels(* 0.10 ** 0.05 *** 0.01 )
/*
----------------------------------------------------------------------------
                      (1)             (2)             (3)             (4)   
                k_y_ratio       k_y_ratio       k_y_ratio       k_y_ratio   
----------------------------------------------------------------------------
ln_gdppc             0.50***         0.60***         0.56***         0.61***
                   (0.02)          (0.10)          (0.09)          (0.06)   
----------------------------------------------------------------------------
N                    9294              11              11              11   
R-sq                 0.08            0.88            0.88            0.94   
----------------------------------------------------------------------------
Standard errors in parentheses
* p<0.10, ** p<0.05, *** p<0.01
*/


