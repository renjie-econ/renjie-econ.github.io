%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Skill Bias, Financial Frictions, and Selection into Entrepreneurship
% Journal of Development Economics
% By Ying Feng, Jie Ren
% This code solves the general equilibrium of the model with capital 
% input for the traditional goods production and generates model moments. 
% It is used for the policy implication section and its robustness check.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
clc

%% initialization

% parameters calibrated to the India economy
P.Am     = 0.3;   % productivity of modern sector
P.gamma  = 0.87;  % 1-gamma: entrepreneur profit share
P.var_h  = 0.1;   % variance of ability distribution
P.lambda = 0.93;  % 1-hazard rate
P.beta   = 0.89;  % discount factor
P.phi_M  = 1.21;  % financial constraint in modern sector 
P.phi_T  = 1.21;  % financial constraint in traditional sector 

% parameters from the U.S. calibration
P.rho    = 2.5;   % elasticity of substitution between traditional and modern sector goods; baseline:2.5
P.theta  = 0.21;  % traditional goods share in consumption expenditure
% P.alpha  = 0.56;  % labor share, for the U.S. only

% assigned parameters
P.delta  = 0.06;  % depreciation rate 
P.sigma  = 1.5;   % risk aversion
P.mean_h = 1;     % mean of ability distribution
P.At     = 1;     % productivity of traditional sector
P.eta    = 0.1;   % capital share in traditional sector; 1/3 for the robusteness check
P.alpha  = 1-1/(3*P.gamma);  % labor share, for the India only

% ability space
P.hgrid      = 800; % grid number
P.hl         = 0;   % lower bound
h_dist_nontr = makedist('Lognormal','mu',log(P.mean_h^2/sqrt(P.var_h+P.mean_h^2)),'sigma',sqrt(log(1+P.var_h/P.mean_h^2))); % non-truncateds distribution
P.hu         = icdf(h_dist_nontr,0.9999); % upper bound
h_dist_tr    = truncate(h_dist_nontr,P.hl,P.hu); % truncated distribution
hspace       = linspace(P.hl,P.hu,P.hgrid); % grids
Muh          = cdf(h_dist_tr,hspace); % CDF
muh          = [0 diff(Muh)]; % PDF
H            = 1:P.hgrid; 

% asset space
P.agrid    = 900;  % grid number
P.al       = eps;  % lower bound
P.au       = 2000; % upper bound
log_aspace = linspace(log(P.al+1),log(P.au+1),P.agrid); % log grids
aspace     = exp(log_aspace)-1; % grids
A          = 1:P.agrid;

% initial guesses
V  = ones(P.hgrid,P.agrid);           % initial guess of value function
g0 = muh(ones(1,P.agrid),:)'/P.agrid; % initial guess of pdf

K_store  = zeros(10,3);
YT_store = zeros(10,3,10);
W_store  = zeros(10,3,10,10);

%% solve for the stationary equilibrium prices using bysection method
flag_w   = 0;      % whether solved equi librium wage
flag_r   = 0;      % ...                      interest rate
flag_Y   = 0;      % ...                      traditional goods price
max_iter = 10;     % maximum iteration number
w_tol    = 1e-5;   % Tolerance value for the upper and lower bound of wages
r_tol    = 1e-5;   % ...                                              interest rate
pT_tol   = 1e-4;   % ...                                              tradtional goods' price
v_tol    = 1e-8;   % Tolerance value for the distance of value function iteration, V and TV
sd_tol   = 1e-10;  % Tolerance value for the stationary distribution iteration

% 1. loop of interest rate r

r_ub   = -0.028; % guess the lower bound of r
r_lb   = -0.027; % guess the upper bound of r
iter_r = 0;     % iteration number of interest rate

while flag_r == 0 && iter_r <= max_iter 
iter_r = iter_r+1;
r      = (r_ub+r_lb)/2; % guess r
if iter_r == 1
    pT_ub  =  0.21;
    pT_lb  =  0.19;
else
    pT_ub  =  pT*1.05; % narrow down the guess range after first iteration
    pT_lb  =  pT*0.95;
end

% 2. loop of traditional sector goods price pT
iter_p = 0;
while flag_Y == 0 && iter_p <= max_iter
    iter_p = iter_p+1;
    pT     = (pT_ub+pT_lb)/2;

if iter_r == 1 && iter_p == 1
    w_ub  =  0.17;
    w_lb  =  0.15;
else
    w_ub  =  w*1.05;
    w_lb  =  w*0.95;
end

% 3. loop of wage rate w
iter_w = 0;
while flag_w == 0 && iter_w <= max_iter
iter_w = iter_w+1;
w      = (w_ub+w_lb)/2; % guess w

% calculate policy function k(h,a) and l(h,a) for employer
k_opt = repmat((P.Am*P.gamma*(1-P.alpha)^(1-P.alpha*P.gamma)*P.alpha^(P.alpha*P.gamma)...
    *w^(-P.alpha*P.gamma)*(r+P.delta)^(P.alpha*P.gamma-1).*hspace').^(1/(1-P.gamma)),1,P.agrid); % optimal capital
if P.phi_M == Inf
    k = k_opt;
else
    constraint = P.phi_M*(repmat(aspace,P.hgrid,1)); % financial constraint
    k          = min(k_opt,constraint); % capital with final constraint
end
l = (P.alpha*P.gamma*P.Am*w^(-1).*k.^((1-P.alpha)*P.gamma).*hspace(ones(1,P.agrid),:)').^(1/(1-P.alpha*P.gamma)); 

% calculate per period income I(h,a) for worker and employer
Iw = w*repmat(hspace',1,P.agrid);
Ie = P.Am.*repmat(hspace',1,P.agrid).*(l.^P.alpha.*k.^(1-P.alpha)).^P.gamma-w*l-(r+P.delta)*k;

% calculate policy function k_T(h,a) for own-account worker
kt_opt=(P.eta*pT*P.At/(r+P.delta))^(1/(1-P.eta));
kt_opt=kt_opt*ones(P.hgrid,P.agrid);
if P.phi_T==Inf
    kt=kt_opt;
else
    constraint_T=P.phi_T*(repmat(aspace,P.hgrid,1));
    kt=min(kt_opt,constraint_T);
end
Io=pT*P.At*kt.^P.eta-(r+P.delta)*kt;

% calculate per period consumption matrix h*a*a': cons_pT*c_T=I^j(h,a)+(1+r)a-a'
cons_pT = pT+((1-P.theta)*pT/P.theta)^P.rho;
CTw     = 1/cons_pT*(bsxfun(@times,Iw,ones(1,1,P.agrid))-reshape(aspace(ones(P.hgrid,P.agrid),:),P.hgrid,P.agrid,P.agrid)+repmat((1+r)*aspace,[P.hgrid 1 P.agrid]));
CTe     = 1/cons_pT*(bsxfun(@times,Ie,ones(1,1,P.agrid))-reshape(aspace(ones(P.hgrid,P.agrid),:),P.hgrid,P.agrid,P.agrid)+repmat((1+r)*aspace,[P.hgrid 1 P.agrid]));
CTo     = 1/cons_pT*(bsxfun(@times,Io,ones(1,1,P.agrid))-reshape(aspace(ones(P.hgrid,P.agrid),:),P.hgrid,P.agrid,P.agrid)+repmat((1+r)*aspace,[P.hgrid 1 P.agrid]));

% per period utility matrix (h*a*a')
cons_util = (P.theta+(1-P.theta)^P.rho*P.theta^(1-P.rho)*pT^(P.rho-1))^(P.rho*(1-P.sigma)/(1-P.rho))/(1-P.sigma);
Uw        = cons_util*(CTw.*(CTw>0)+eps).^(1-P.sigma); 
Ue        = cons_util*(CTe.*(CTe>0)+eps).^(1-P.sigma); 
Uo        = cons_util*(CTo.*(CTo>0)+eps).^(1-P.sigma); 

% value function iteration
v_dist    = 1;                        % distance between V and TV
TV_choice = zeros(P.hgrid,P.agrid,3); % values of wage worker, employer and own-account worker

while v_dist > v_tol
       EV = P.lambda.*reshape(V(H,A(ones(1,P.agrid),:)),P.hgrid,P.agrid,P.agrid)...
           +(1-P.lambda).*reshape(kron(sum(repmat(muh',1,P.agrid).*V),ones(P.hgrid,P.agrid)),P.hgrid,P.agrid,P.agrid); % expected next period value
       
       [TV_choice(:,:,1),a_policy_temp1] = max(Uw+P.beta.*EV,[],3);% value and policy function of being wage worker
       [TV_choice(:,:,2),a_policy_temp2] = max(Ue+P.beta.*EV,[],3);% value and policy function of being employer
       [TV_choice(:,:,3),a_policy_temp3] = max(Uo+P.beta.*EV,[],3);% value and policy function of being own-account worker
       [TV,O]                            = max(TV_choice,[],3);    % occupational choice as the maximum of worker, employer and own-account's value
       
       a_policy = a_policy_temp1.*(O==1)+a_policy_temp2.*(O==2)+a_policy_temp3.*(O==3); % policy function given occupation
       v_dist   = max(max(abs(TV-V)));
       V = TV;
end

% policy function of consumption on (h,a)
cT = 1/cons_pT.*(Iw.*(O==1)+Ie.*(O==2)+Io.*(O==3)+repmat((1+r)*aspace,P.hgrid,1)-aspace(a_policy));
cM = ((1-P.theta)*pT/P.theta)^P.rho*cT;

% compute the stationary distribution matrix
a_indicator = zeros(P.hgrid,P.agrid,P.agrid);  %indicator matrix (h*a*a'); =1 if a_policy=a'
for a = 1:P.agrid
    a_indicator(:,:,a) = (a_policy==a);
end

sd_dist = 1;
while sd_dist>sd_tol
    % update distribution                
    g_prime = reshape(repmat(g0,1,P.agrid),P.hgrid,P.agrid,P.agrid).*a_indicator;  
    g       = P.lambda*reshape(sum(g_prime,2),P.hgrid,P.agrid)... %1. h does not change and a'=a;
         +(1-P.lambda)*repmat(reshape(sum(g_prime,[1 2]),1,P.agrid),P.hgrid,1).*repmat(muh',1,P.agrid); 
         % 2. a'=a, and with probability mu(h) that h'=h under productivity shock
         
    sd_dist = max(max(abs(g-g0)));
    g0 = g;
end

Ws  = sum(g.*repmat(hspace',1,P.agrid).*(O==1),'all'); % supply of labor
Wd  = sum(g.*l.*(O==2),'all');                         % demand of labor
Ks  = sum(g.*repmat(aspace,P.hgrid,1),'all');          % supply of capital 
Kd  = sum(g.*k.*(O==2),'all')+sum(g.*kt.*(O==3),'all');% demand of capital
YTs = sum(g.*P.At.*kt.^P.eta.*(O==3),'all');           % supply of traditional sector goods
YTd = sum(g.*cT,'all');                                % demand of traditional sector goods

% check labor market clearance condition
W_store(iter_w,:,iter_p,iter_r) = [Wd,Ws,w];

% stop iteration if lower and upper bound of wage is too close or the labor market clears
if w_ub-w_lb < w_tol || abs(Wd-Ws)/min(Wd,Ws) <= 1e-3
    flag_w   = 1;
elseif w_ub-w_lb >= w_tol && Wd > Ws % increase guessed wage if demand is greater than supply
    w_lb     = w;
elseif w_ub-w_lb >= w_tol && Wd < Ws % decrease guessed wage if demand is less than supply
    w_ub     = w;
end
end

% check traditional goods market clearance condition 
YT_store(iter_p,:,iter_r) = [YTd,YTs,pT];
% stop iteration if lower and upper bound of wage are too close or tradtional goods market clears
if pT_ub-pT_lb < pT_tol || abs(YTd-YTs)/min(YTd,YTs) <= 1e-3
    flag_Y = 1;
elseif pT_ub-pT_lb >= pT_tol && YTd > YTs % increase guessed wage if demand is greater than supply
    pT_lb   = pT;
    flag_w = 0;
elseif  pT_ub-pT_lb >= pT_tol && YTd < YTs % decrease guessed wage if demand is less than supply
    pT_ub   = pT;
    flag_w = 0;
end
end

% check capital market clearance condtion
K_store(iter_r,:)=[Kd,Ks,r];
%stop iteration if lower and upper bound of rental rate are too close or the capital market clears
if r_ub-r_lb < r_tol || abs(Kd-Ks)/min(Kd,Ks) <= 1e-3
    flag_r = 1;
elseif r_ub-r_lb >= r_tol && Kd > Ks % increase guessed rental rate if demand is greater than supply       
    flag_w = 0;
    flag_Y = 0;
    r_lb   = r;
elseif r_ub-r_lb >= r_tol && Kd < Ks % decrease guessed rental rate if demand is less than supply
    flag_w = 0; 
    flag_Y = 0;
    r_ub=r;
end
end

% check market clearance conditions and equilibrium prices 
label     = ["r";"w";"pT"];
price     = [r;w;pT];
demand    = [Kd;Wd;YTd];
supply    = [Ks;Ws;YTs];
distance  = [abs(Kd-Ks)/min(Kd,Ks); abs(Wd-Ws)/min(Wd,Ws); abs(YTd-YTs)/min(YTd,YTs)];
eq_result = table(label,price,demand,supply,distance)

%% simulation 
n  = 1e6;  % sample size
rng('default')

ha                    = randsample(P.hgrid*P.agrid,n,true,reshape(g,[P.hgrid*P.agrid,1])); % generate n individuals distributed as g
h_sample              = mod(ha,P.hgrid);          
h_sample(h_sample==0) = P.hgrid;                  % index of ability 
a_sample              = floor((ha-1)/P.hgrid)+1;  % index of asset

% upon shock on ability, the next period draw of ability
shock                           = rand(n,1);   
h_prime_sample                  = randsample(P.hgrid,n,true,muh); 
h_prime_sample(shock<=P.lambda) = h_sample(shock<=P.lambda);

a_policy_sample = zeros(n,1); % index of next period asset holding
O_sample        = zeros(n,1);        % index of occupation: 1. wage worker; 2. employer; 3. own-account worker
O_prime_sample  = zeros(n,1);  % index of next period occupation
I_sample        = zeros(n,1);        % per period income
k_sample        = zeros(n,1);        % capital used
l_sample        = zeros(n,1);        % labor hired 
ym_sample       = zeros(n,1);       % output of modern sector goods
cT_sample       = zeros(n,1);       % consumption
debt_sample     = zeros(n,1);     % debt (if >0)
yt_sample       = zeros(n,1);       % output of traditional sector goods

for i=1:n
   a_policy_sample(i) = a_policy(h_sample(i),a_sample(i));
   O_sample(i)        = O(h_sample(i),a_sample(i));
   O_prime_sample(i)  = O(h_prime_sample(i),a_policy_sample(i)); 
   cT_sample(i)       = cT(h_sample(i),a_sample(i));
   
   if O_sample(i) == 2     % for current employer
   I_sample(i)    =  Ie(h_sample(i),a_sample(i));
   k_sample(i)    =  k(h_sample(i),a_sample(i));
   l_sample(i)    =  l(h_sample(i),a_sample(i));
   ym_sample(i)   =  P.Am*hspace(h_sample(i))*(l_sample(i)^P.alpha*k_sample(i)^(1-P.alpha))^P.gamma;
   debt_sample(i) =  k_sample(i)-aspace(a_sample(i));
   
   elseif O_sample(i) == 1 % for wage worker
       I_sample(i)    =  w*hspace(h_sample(i));
       
   else % for own-account worker
       k_sample(i)    =  kt(h_sample(i),a_sample(i));
       yt_sample(i)   =  P.At*k_sample(i)^P.eta;
       I_sample(i)    =  pT*yt_sample(i);
       debt_sample(i) =  k_sample(i)-aspace(a_sample(i));
   end
end
k_aggregate  = sum(k_sample);
yt_aggregate = sum(yt_sample);
cT_aggregate = sum(cT_sample);
ym_aggregate = sum(ym_sample);
cM_aggregate = ((1-P.theta)*pT/P.theta)^P.rho*sum(cT_sample);
u_sample     = cons_util*cT_sample.^(1-P.sigma);
s_sample     = aspace(a_sample)-aspace(a_policy_sample);

%% moments for calibration; run this section for calibration only 
% 1. own-account share
o_share = sum((O_sample==3),'all')/n;

% 2. employer share
e_share = sum((O_sample==2),'all')/n;

% 3. employer exit rate
exit_rate = sum((O_prime_sample~=2).*(O_sample==2))/sum((O_prime_sample==2));

% 4. Gini coefficient
gini_coefficient = Gini(I_sample);

% 5. capital to output ratio
GDP_i = sum(I_sample)+(r+P.delta)*k_aggregate;
GDP_e = pT*cT_aggregate+cM_aggregate+sum(aspace(a_policy_sample)-aspace(a_sample))+P.delta*k_aggregate;
GDP_o = yt_aggregate*pT+ym_aggregate;

k_to_y = k_aggregate/GDP_o;

% 6. debt-to-output ratio, for India only
d_to_gdp = sum(debt_sample(debt_sample>0))/GDP_o;  

% 7. expenditure share of traditional sector goods, for the U.S. and cross-country only
t_exp_share = cT_aggregate*pT/GDP_o;

% 8. capital share, for the U.S. and cross-country only
capital_share = (r+P.delta)*k_aggregate/GDP_o;

para       = ["Am";"gamma";"var_h";"lambda";"beta";"phi_T";"phi_M";"theta";"alpha";];
para_value = [P.Am;P.gamma;P.var_h;P.lambda;P.beta;P.phi_T;P.phi_M;P.theta;P.alpha];
moments    = ["own-account share";"employer share";"Gini Coefficient";...
    "employer exit rate";"capital-to-output";"debt-to-GDP";"null";...
    "expenditure share";"capital share"];
% data       = [0.10;0.071;0.4;0.083;3;3.1;0;0.05;0.33]; % the U.S. moments
data       = [0.43;0.021;0.32;0.047;1.9;0.31;0;0;0.33]; % the India moments
model      = [o_share;e_share;gini_coefficient;exit_rate;k_to_y;d_to_gdp;0;t_exp_share;capital_share];
result     = table(para,para_value,moments,data,model)

%% moments for quantitative analysis; run this section for quantitative analysis only
% 1. own-account share
o_share = sum((O_sample==3),'all')/n;

% 2. employer share
e_share = sum((O_sample==2),'all')/n;

% 3. tradtional sector capital usage
K_T = sum(k_sample.*(O_sample==3));
        
% 4. modern sector capital usage
K_M = sum(k_sample.*(O_sample==2));

% 5. traditional sector TFP
N_T       = sum((O_sample==3));
K_share_T = k_sample/K_T.*(O_sample==3);
TFP_T     = P.At*sum(K_share_T.^P.eta)/N_T^(1-P.eta);

% 6. modern sector TFP
W_M       = sum(l_sample);        % aggregate labor input in efficiency unit
N_M       = W_M+sum((O_sample==2)); % aggregate total labor input (including the unweighted entrepreneurial input)
K_share_M = k_sample./K_M.*(O_sample==2);    % share of capital employed by each employer
temp      = sum((hspace(h_sample)').^(1/(1-P.alpha*P.gamma)).*K_share_M.^((1-P.alpha)*P.gamma/(1-P.alpha*P.gamma)));
TFP_M     = P.Am*W_M^(P.alpha*P.gamma)*temp^(1-P.alpha*P.gamma)/N_M^(1-(1-P.alpha)*P.gamma);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%functions%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function gini = Gini(x)

%This function is used to calculate the Gini coefficient.

x_sort = sortrows(x);
N      = size(x_sort);
N      = N(1);
gini   = 1-2/(N+1)*sum(cumsum(x_sort))/sum(x_sort);

end
